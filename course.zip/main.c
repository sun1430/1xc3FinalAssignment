/**
 * @mainpage Course demonstration
 * - Print the Name, Code, Total students of the course.
 * - Print all the student in the course with their Name, ID, Grades, Average.
 * - Print the top sudent in the course.
 * - Print all the students that passed this course.
 * 
 *
 * @file main.c
 * @author Zhifu Sun
 * @brief Runs a demonstration of a course name "Basics of Mathematics" and gives the student names and grades randomly
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"
/**
 * @brief main function that will runs the program.
 * 
 * @return none 
 */
int main()
{
  srand((unsigned) time(NULL)); /**<set seed to generate random*/

  Course *MATH101 = calloc(1, sizeof(Course)); /**<memory allocation for a course*/
  strcpy(MATH101->name, "Basics of Mathematics"); /**<assign course name*/
  strcpy(MATH101->code, "MATH 101"); /**<assign course code*/

  for (int i = 0; i < 20; i++) /**<add random students to course*/
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101); /**<print course*/

  Student *student;
  student = top_student(MATH101); /**<get the address of top student*/
  printf("\n\nTop student: \n\n");
  print_student(student); /**<print top student*/

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing); /**<get the array of all pass students*/
  printf("\nTotal passing: %d\n", total_passing); /**<print amount of pass*/
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); /**<loop to print pass students*/
  
  return 0;
}