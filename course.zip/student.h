/**
 * @file student.h
 * @author Zhifu Sun
 * @brief student struct and functions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief strcut with first and last name, ID, pointer of grades , amount of grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the first name array*/
  char last_name[50]; /**< the last name array*/
  char id[11]; /**< the ID array*/
  double *grades;  /**< the grades pointer*/
  int num_grades; /**< amount of grades */
} Student;
/**
 * @brief 
 * 
 * @param student 
 * @param grade 
 * @return nothing
 */
void add_grade(Student *student, double grade);
/**
 * @brief 
 * 
 * @param student 
 * @return double 
 */
double average(Student *student);
/**
 * @brief 
 * 
 * @param student 
 * @return nothing
 */
void print_student(Student *student);
/**
 * @brief 
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades); 
