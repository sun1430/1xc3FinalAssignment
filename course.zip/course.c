/**
 * @file course.c
 * @author Zhifu Sun
 * @brief definiton of functions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief add new student to the course
 * 
 * @param course pointer
 * @param student pointer
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); /**<memory allocation for nothing in the course->students*/
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); /**<re-allocate memory for more student*/
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief print out name, code and number of students of a course
 * 
 * @param course pointer
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) /**<print out information of every student using loop*/
    print_student(&course->students[i]);
}
/**
 * @brief a function that return the student who has the highest average 
 * 
 * @param course pointer of course
 * @return Student*
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0]; 
 
  for (int i = 1; i < course->total_students; i++) /**<loop to calculate the average and compare to the previous highest, and get the highest*/
  {
    student_average = average(&course->students[i]); /**<calculate the average*/
    if (student_average > max_average) /**<save the highest*/
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief return a dynamic memory of student who pass and save the num of those students in to a address called total_passing
 * 
 * @param course pointer of course
 * @param total_passing pointer of amount of pass
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) /**<loop to count the amount of pass*/
    if (average(&course->students[i]) >= 50) count++; 
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++) /**<loop to get every pass student into the array*/
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count; /**<save the amount to the address*/

  return passing;
}