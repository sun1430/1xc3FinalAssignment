/**
 * @file student.c
 * @author Zhifu Sun
 * @brief definitions of student function
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief  add the grade for a student 
 * 
 * @param student pointer
 * @param grade double
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); /**<memory allocation for nothing in student->grades*/
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); /**<re-allocate if there is more grades*/
  }
  student->grades[student->num_grades - 1] = grade;
}
/**
 * @brief calculate the average grades for a student
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; /**<get the sum of grades*/
  return total / ((double) student->num_grades); /**<return the average grade*/
}
/**
 * @brief print the student's Name, ID, Grades, Average.
 * 
 * @param student 
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) /**<print every grades with only 2 decimals*/
    printf("%.2f ", student->grades[i]); 
  printf("\n");
  printf("Average: %.2f\n\n", average(student)); /**<print average grade*/
}
/**
 * @brief generate student with random name and grade
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"}; /**<list of first name*/

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"}; /**<list of last name*/

  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]); /**<assign random first name from the above array*/
  strcpy(new_student->last_name, last_names[rand() % 24]); /**<assign random last name from the above array*/

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); /**<loop to give random ID*/
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) /**<loop to give random grade*/
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}